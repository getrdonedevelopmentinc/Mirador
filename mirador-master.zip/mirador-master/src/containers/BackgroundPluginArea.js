import { withPlugins } from '../extend/withPlugins';
import { BackgroundPluginArea } from '../components/BackgroundPluginArea';

export default withPlugins('BackgroundPluginArea')(BackgroundPluginArea);
