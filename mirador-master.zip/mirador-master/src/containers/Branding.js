import { withPlugins } from '../extend/withPlugins';
import { Branding } from '../components/Branding';

export default withPlugins('Branding')(Branding);
